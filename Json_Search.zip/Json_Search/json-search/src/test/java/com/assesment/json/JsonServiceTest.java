/**
 * 
 */
package com.assesment.json;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class JsonServiceTest extends TestCase {

	/**
	 * Create the test case
	 *
	 * @param testName name of the test case
	 */
	public JsonServiceTest(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(JsonServiceTest.class);
	}

	@org.junit.Test
	public void testFindText() {
		JsonService service = new JsonService();
		assertEquals(Constants.NO_RESULT.getText(),service.findText("hello"));
		assertEquals(Constants.INVALID_INPUT.getText(),service.findText(""));
		service.findText("Action");
		service.findText("Jeremy Renner");
		service.findText("Chris");
		service.findText("Adam");
	}
}
