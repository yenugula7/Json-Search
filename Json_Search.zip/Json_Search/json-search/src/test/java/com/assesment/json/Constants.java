/**
 * 
 */
package com.assesment.json;

/**
 * @author Kotireddy Sareddy
 *
 */
public enum Constants {

	NO_RESULT("No text found"),
	INVALID_INPUT("Invalid text");
	

	private String text;

	Constants(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}
}
