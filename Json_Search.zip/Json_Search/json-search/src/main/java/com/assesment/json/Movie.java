/**
 * 
 */
package com.assesment.json;

import java.util.List;

public class Movie {

	private String title;
	private String year;
	private List<String> cast;
	private List<String> generes;
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return the cast
	 */
	public List<String> getCast() {
		return cast;
	}
	/**
	 * @param cast the cast to set
	 */
	public void setCast(List<String> cast) {
		this.cast = cast;
	}
	/**
	 * @return the generes
	 */
	public List<String> getGeneres() {
		return generes;
	}
	/**
	 * @param generes the generes to set
	 */
	public void setGeneres(List<String> generes) {
		this.generes = generes;
	}
	
}
