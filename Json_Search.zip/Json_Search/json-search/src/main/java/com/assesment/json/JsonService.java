/**
 * 
 */
package com.assesment.json;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JsonService {
	private static final String JSON_FILE = "movies.json";
	public String findText(String phrase) {
		boolean isFound = false;
		String result = "";
		if (phrase != null && !phrase.equals("")) {
			Gson gson = new Gson();
			StringBuilder displayContent = new StringBuilder();
			int count = 0;
			ClassLoader classLoader = getClass().getClassLoader();
			try (Reader reader = new FileReader(classLoader.getResource(JSON_FILE).getFile())) {
				List<Movie> movies = gson.fromJson(reader, new TypeToken<List<Movie>>() {
				}.getType());
				if (movies != null) {

					for (Movie movie : movies) {
						if (movie.getTitle().contains(phrase)) {
							isFound = true;
							count++;
						}
						if (movie.getCast() != null) {
							for (String cast : movie.getCast()) {
								if (cast.contains(phrase)) {
									isFound = true;
									count++;
								}
							}
						}
						if (movie.getGeneres() != null) {
							for (String genre : movie.getGeneres()) {
								if (genre.contains(phrase)) {
									isFound = true;
									count++;
								}
							}
						}
						if (isFound) {
							if (count > 0) {
								displayContent.append(Constants.QUOTE.getText()).append(movie.getTitle()).
								append(Constants.QUOTE.getText()).append(Constants.COMMA.getText());
							}

						}

					}
				}
				int contentLength = displayContent.length() - 2;
				if (contentLength > 2) {
					displayContent.replace(contentLength, contentLength + 1, String.valueOf(""));
					displayContent.append(Constants.COUNT.getText()).append(count);
				}
				result = displayContent.toString();
				if (count > 1) {
					result = Constants.MOVIES.getText() + result;
				}
				if (count == 1) {
					result = Constants.MOVIE.getText() + result;
				}

			} catch (IOException e) {
				e.printStackTrace();
			} 
			if(!isFound) {
				return Constants.NO_RESULT.getText();
			}
		}else {
			return Constants.INVALID_INPUT.getText();
		}
		return result;
	}
	
}
