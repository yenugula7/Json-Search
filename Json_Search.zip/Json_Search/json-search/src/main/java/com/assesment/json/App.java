package com.assesment.json;

/**
 * Hello world!
 *
 */
public class App {
	
	public static void main(String[] args) {
		
		JsonService service = new JsonService();
		System.out.println(service.findText("Chris"));
	}
}
