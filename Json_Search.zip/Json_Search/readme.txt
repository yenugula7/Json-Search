Technologies Used:-
------------------
1.	Java - 1.8 
2.	Gson - 2.6.2 -> Json Parsing Binary
3.	Junit – 4.12 -> Unit Test Binary
4.	Maven – 3.5.4 -> Build Tool

Import to any Java IDE as maven project and can run this project.
